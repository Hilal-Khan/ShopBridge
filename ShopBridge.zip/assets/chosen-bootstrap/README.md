# Chosen (for LESS and Twitter Bootstrap)

This fork of Chosen has been adapted to LESS + Twitter Bootstrap.
Sass-to-LESS converted by [@rajunov](http://www.twitter.com/bookmousey).

## This just rides on the coattails of better contributors:

The Harvest Team:

- [Chosen](http://harvesthq.github.com/chosen/)
- [Harvest](http://www.getharvest.com/)
- [Patrick Filler](http://www.patrickfiller.com/)
- [Matthew Lettini](http://matthewlettini.com/)

The Twitter Bootstrap Team:

- [Twitter Bootstrap](http://twitter.github.com/bootstrap/)
- [@mdo](http://www.twitter.com/mdo)
- [@fat](http://www.twitter.com/fat)

John Long:

- [Twitter Bootstrap Sass Conversion](https://github.com/jlong/sass-twitter-bootstrap)
- [@johnwlong](http://www.twitter.com/johnwlong)

Joey Lomanto: 

- [Chosen Bootstrap Sass Conversion](http://chosen-sass-bootstrap.herokuapp.com/)
- [@joeylomanto](http://www.twitter.com/joeylomanto)