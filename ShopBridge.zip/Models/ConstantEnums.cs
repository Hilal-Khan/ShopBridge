﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopBridge.Models
{
    public class ConstantEnums
    {

        public enum FileUploaderPath
        {
            Product
        };

        public enum MessageType
        {
            Success,
            Error
        };

    }
}